qemu-system-i386 -fda ../01HelloWorld/main.img -boot a -s -S -monitor stdio


